package board.service;

import java.util.List;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import board.dto.BoardDTO;

public interface BoardService {

	List<BoardDTO> selectBoardList();

	void insertBoard(BoardDTO board, MultipartHttpServletRequest multipartHttpServletRequest);

	BoardDTO selectBoardDetail(int no);

	void updateBoard(BoardDTO dto);

	void deleteBoard(int no);

}
