package board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import board.dto.BoardDTO;
import board.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	BoardMapper boardMapper;

	@Override
	public List<BoardDTO> selectBoardList() {
		// 비지니스 로직
		// DB처리---> 
		System.out.println("selectBoardList 처리");
		return boardMapper.selectBoardList();
	}

	@Override
	public void insertBoard(BoardDTO board) {
		//DB처러
		boardMapper.insertBoard(board);
	}
	
	@Transactional
	@Override
	public BoardDTO selectBoardDetail(int no) {
		// 조회수 증가처리...
		boardMapper.updateBoardCount(no);
		System.out.println("조회수 증가 완료!");
		int n=Integer.parseInt("aaa");
		//Detail정보 리턴
		return boardMapper.selectBoardDetail(no);
	}
	
	@Transactional
	@Override
	public void updateBoard(BoardDTO dto) {
		boardMapper.updateBoard(dto);
		System.out.println("수정완료!");
		int n=Integer.parseInt("aaa");
		System.out.println("n: "+n);
	}

	@Override
	public void deleteBoard(int no) {
		boardMapper.deleteBoard(no);
		
	}

}
