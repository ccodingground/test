package board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import board.dto.BoardDTO;
import board.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	BoardMapper boardMapper;

	@Override
	public List<BoardDTO> selectBoardList() {
		// 비지니스 로직
		// DB처리---> 
		return boardMapper.selectBoardList();
	}

	@Override
	public void insertBoard(BoardDTO board) {
		//DB처러
		boardMapper.insertBoard(board);
	}

	@Override
	public BoardDTO selectBoardDetail(int no) {
		// 조회수 증가처리...
		boardMapper.updateBoardCount(no);
		//Detail정보 리턴
		return boardMapper.selectBoardDetail(no);
	}

}
