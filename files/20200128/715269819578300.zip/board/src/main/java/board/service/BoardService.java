package board.service;

import java.util.List;

import board.dto.BoardDTO;

public interface BoardService {

	List<BoardDTO> selectBoardList();

	void insertBoard(BoardDTO board);

	BoardDTO selectBoardDetail(int no);

	void updateBoard(BoardDTO dto);

	void deleteBoard(int no);

}
