package board.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import board.interceptor.TestInterceptor;

//WebMvcConfigurerAdapter 클래스 상속 대신 WebMvcConfigurer implements해서 사용
@Configuration
public class WebConfiguration implements WebMvcConfigurer{
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new TestInterceptor())
		  .excludePathPatterns("/board/open*")//제외할 요청 주소 패턴 등록
		  .addPathPatterns("/board/insert*");//적용할 요청 주소 패턴 등록 //패턴 등록이나 제외 없으면 모든 패턴
	}

}
